# Vaccine-Usage-Prediction-by-Logistic-Regression
Logistic Regression is a supervised learning algorithm. This project is based on a classification problem where the objective is to predict how likely it is that the people will take an H1N1 flu vaccine. The dataset consists of 34 predictors including target variable i.e. h1n1 vaccine.
